#pragma once
#include<iostream>
class Groups {
public:
	std::string gr_name[3];
	std::string Gr_mem[3];
};
